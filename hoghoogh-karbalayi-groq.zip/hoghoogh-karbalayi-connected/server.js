"use strict";
const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
app.disable("x-powered-by");
app.use(express.json({ limit: "25kb" }));
app.use(express.static(path.join(__dirname, "public")));
const AI_BASE_URL = (process.env.AI_BASE_URL || "https://api.groq.com/openai/v1").replace(/\/+$/, "");
const AI_MODEL = process.env.AI_MODEL || "openai/gpt-oss-120b";
app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "حقوق کربلایی", ai: "Groq API", model: AI_MODEL }));
const validTypes = ["مشاوره حقوقی", "دادخواست", "شکواییه", "لایحه", "اظهارنامه", "نامه یا درخواست اداری"];
app.post("/api/legal-draft", async (req, res) => {
  try {
    const { documentType, description, extra } = req.body || {};
    if (typeof documentType !== "string" || !validTypes.includes(documentType)) return res.status(400).json({ error: "نوع درخواست معتبر نیست." });
    if (typeof description !== "string" || description.trim().length < 10) return res.status(400).json({ error: "لطفاً موضوع را حداقل در چند جمله توضیح بده." });
    if (description.length > 10000 || (typeof extra === "string" && extra.length > 4000)) return res.status(400).json({ error: "متن ورودی بیش از حد طولانی است." });
    const apiKey = process.env.AI_API_KEY;
    if (!apiKey) return res.status(503).json({ error: "اتصال دستیار هوشمند هنوز کامل نشده است. مدیر برنامه باید کلید API را در تنظیمات محرمانه سرور وارد کند." });
    const isAdvice = documentType === "مشاوره حقوقی";
    const system = `شما دستیار فارسی‌زبان حقوقی برنامه «حقوق کربلایی» هستید. موضوع را بر اساس قوانین ایران بررسی کن مگر کاربر کشور دیگری بگوید. پاسخ را روشن، کاربردی، منظم و با فارسی روان بنویس. هیچ واقعیت، تاریخ، مدرک، ماده قانونی، شماره رأی یا نقل‌قولی را جعل نکن. اگر از صحت یا جاری بودن مقرره مطمئن نیستی، صریح بگو و از ساختن استناد خودداری کن. بین گفته کاربر و واقعیت اثبات‌شده تفاوت بگذار. اگر اطلاعات ضروری کم است، سؤال‌های کوتاه و مشخص بپرس یا موارد نامعلوم را با [جای خالی] نشان بده. از درخواست اطلاعات حساس غیرضروری خودداری کن. ${isAdvice ? "برای مشاوره از این ساختار استفاده کن: خلاصه مسئله، نکات حقوقی، راهکارهای احتمالی، مدارک لازم، اقدام بعدی و ابهام‌ها." : "برای سند، عنوان، مرجع در صورت معلوم بودن، شرح ماجرا، دلایل و مستندات، خواسته یا درخواست نهایی و فهرست موارد ناقص را بیاور."} اگر موضوع به مهلت قانونی، ابلاغ، اجرای حکم یا خطر فوری مربوط است، ضرورت بررسی سریع را روشن بیان کن. از عنوان‌های روشن و متن قابل استفاده و حرفه‌ای بهره ببر.`;
    const userText = `نوع درخواست: ${documentType}\nشرح موضوع:\n${description.trim()}${typeof extra === "string" && extra.trim() ? `\n\nاطلاعات تکمیلی:\n${extra.trim()}` : ""}`;
    const response = await fetch(`${AI_BASE_URL}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify({ model: AI_MODEL, messages: [{ role: "system", content: system }, { role: "user", content: userText }], temperature: 0.25, max_tokens: 8192 }),
      signal: AbortSignal.timeout(60000)
    });
    if (!response.ok) {
      const details = await response.text();
      console.error("AI provider error", response.status, details.slice(0, 700));
      if (response.status === 429) return res.status(429).json({ error: "سرویس هوش مصنوعی فعلاً به سقف مصرف یا محدودیت موقت رسیده است. کمی بعد دوباره تلاش کن." });
      if (response.status === 401 || response.status === 403) return res.status(502).json({ error: "کلید API یا دسترسی مدل پذیرفته نشد. تنظیمات سرویس را بررسی کن." });
      return res.status(502).json({ error: "سرویس هوش مصنوعی موقتاً پاسخ نداد. لطفاً چند دقیقه دیگر دوباره تلاش کن." });
    }
    const data = await response.json();
    const result = data?.choices?.[0]?.message?.content;
    const text = typeof result === "string" ? result.trim() : Array.isArray(result) ? result.map(p => p.text || "").join("\n").trim() : "";
    if (!text) return res.status(502).json({ error: "پاسخ قابل استفاده دریافت نشد. دوباره تلاش کن." });
    return res.json({ success: true, result: text });
  } catch (err) {
    console.error("Request error", err.message);
    return res.status(502).json({ error: "در حال حاضر امکان برقراری ارتباط با دستیار هوشمند فراهم نیست. لطفاً چند دقیقه دیگر دوباره تلاش کنید." });
  }
});
app.listen(PORT, "0.0.0.0", () => console.log(`Hoghoogh Karbalayi running on ${PORT}; AI base: ${AI_BASE_URL}; model: ${AI_MODEL}`));
